// JavaScript to handle modal behavior and navigation

// Open booking modal
function openModal() {
    document.getElementById("bookingModal").style.display = "block";
}

// Close booking modal
function closeModal() {
    document.getElementById("bookingModal").style.display = "none";
}

// Smooth scroll to section
function scrollToSection(sectionId) {
    document.getElementById(sectionId).scrollIntoView({ behavior: 'smooth' });
}

// Submit booking form
document.getElementById("bookingForm").addEventListener("submit", function(event) {
    event.preventDefault();
    alert("Booking submitted successfully!");
    closeModal();
});
